const express = require("express");
const cors = require("cors");
const { Readable } = require("stream");
const { ANIME } = require("@consumet/extensions");

const app = express();
app.use(cors({ origin: true, exposedHeaders: ["content-length", "content-range", "accept-ranges"] }));
app.use(express.json());

const anime = new ANIME.AnimeUnity();
const PORT = Number(process.env.PORT || 3000);
const DEFAULT_REFERER = "https://www.animeunity.to/";
const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36";

const upstreamHeaders = (referer, req) => {
  let origin = "https://www.animeunity.to";
  try { origin = new URL(referer || DEFAULT_REFERER).origin; } catch (_) {}

  const headers = {
    "user-agent": USER_AGENT,
    accept: req.headers.accept || "*/*",
    referer: referer || DEFAULT_REFERER,
    origin,
  };
  if (req.headers.range) headers.range = req.headers.range;
  return headers;
};

const proxyLink = (absoluteUrl, referer) =>
  `/api/proxy?url=${encodeURIComponent(absoluteUrl)}&referer=${encodeURIComponent(referer || DEFAULT_REFERER)}`;

const absoluteFrom = (value, base) => {
  try { return new URL(value, base).toString(); } catch (_) { return value; }
};

const rewritePlaylist = (text, playlistUrl, referer) => {
  const rewriteAttributeUris = (line) => line.replace(/URI=("([^"]+)"|'([^']+)')/g, (_match, quoted, dq, sq) => {
    const uri = dq || sq || "";
    const absolute = absoluteFrom(uri, playlistUrl);
    return `URI="${proxyLink(absolute, referer)}"`;
  });

  return text
    .split(/\r?\n/)
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return line;
      if (trimmed.startsWith("#")) return rewriteAttributeUris(line);
      // Media playlist entries and variant playlists can both be relative.
      return proxyLink(absoluteFrom(trimmed, playlistUrl), referer);
    })
    .join("\n");
};

app.get("/", (_req, res) => {
  res.json({ status: "ok", service: "Name Anime streaming backend", provider: "AnimeUnity", proxy: true });
});

app.get("/health", (_req, res) => res.json({ ok: true, provider: "AnimeUnity", proxy: true }));

app.get("/api/search", async (req, res) => {
  try {
    const query = String(req.query.q || "").trim();
    const page = Number(req.query.page || 1);
    if (!query) return res.status(400).json({ error: "Missing q parameter" });
    res.json(await anime.search(query, page));
  } catch (error) {
    console.error("Search error:", error);
    res.status(500).json({ error: "Anime search failed", message: error.message });
  }
});

app.get("/api/info/:id(*)", async (req, res) => {
  try {
    const id = req.params.id;
    if (!id) return res.status(400).json({ error: "Missing anime id" });
    res.json(await anime.fetchAnimeInfo(id));
  } catch (error) {
    console.error("Anime info error:", error);
    res.status(500).json({ error: "Anime info lookup failed", message: error.message });
  }
});

app.get("/api/sources/:id(*)", async (req, res) => {
  try {
    const id = req.params.id;
    if (!id) return res.status(400).json({ error: "Missing episode id" });
    const result = await anime.fetchEpisodeSources(id);
    // AnimeUnity's stream host expects requests to originate from AnimeUnity.
    // Keep this header with the source result so the frontend can build proxy URLs.
    res.json({ ...result, headers: { ...(result?.headers || {}), Referer: result?.headers?.Referer || DEFAULT_REFERER } });
  } catch (error) {
    console.error("Episode source error:", error);
    res.status(500).json({ error: "Episode source lookup failed", message: error.message });
  }
});

app.get("/api/proxy", async (req, res) => {
  const rawUrl = String(req.query.url || "");
  const referer = String(req.query.referer || DEFAULT_REFERER);

  if (!rawUrl) return res.status(400).send("Missing url parameter");

  let target;
  try {
    target = new URL(rawUrl);
    if (!["http:", "https:"].includes(target.protocol)) throw new Error("Unsupported protocol");
  } catch (error) {
    return res.status(400).send("Invalid proxy URL");
  }

  try {
    const upstream = await fetch(target.toString(), {
      headers: upstreamHeaders(referer, req),
      redirect: "follow",
    });

    if (!upstream.ok && upstream.status !== 206) {
      const body = await upstream.text().catch(() => "");
      console.error("Proxy upstream error", upstream.status, target.toString(), body.slice(0, 200));
      return res.status(upstream.status).send(body || `Upstream HTTP ${upstream.status}`);
    }

    const finalUrl = upstream.url || target.toString();
    const type = (upstream.headers.get("content-type") || "").toLowerCase();
    const looksLikePlaylist = type.includes("mpegurl") || type.includes("m3u8") || new URL(finalUrl).pathname.toLowerCase().includes(".m3u8") || finalUrl.includes("playlist");

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cache-Control", looksLikePlaylist ? "no-store" : "public, max-age=60");

    if (looksLikePlaylist) {
      const text = await upstream.text();
      res.type("application/vnd.apple.mpegurl");
      return res.send(rewritePlaylist(text, finalUrl, referer));
    }

    for (const header of ["content-type", "content-length", "content-range", "accept-ranges", "etag", "last-modified"]) {
      const value = upstream.headers.get(header);
      if (value) res.setHeader(header, value);
    }
    res.status(upstream.status);

    if (!upstream.body) return res.end();
    Readable.fromWeb(upstream.body).on("error", (error) => {
      console.error("Proxy stream error:", error);
      if (!res.headersSent) res.status(502);
      res.end();
    }).pipe(res);
  } catch (error) {
    console.error("Proxy request failed:", error);
    if (!res.headersSent) res.status(502).json({ error: "Proxy request failed", message: error.message });
    else res.end();
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Name Anime backend listening on port ${PORT}`);
  console.log("HLS proxy enabled at /api/proxy");
});
