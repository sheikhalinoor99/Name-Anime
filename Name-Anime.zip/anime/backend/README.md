# Next Anime - AnimeUnity Backend

The existing Next Anime UI uses this separate Node/Express service for AnimeUnity search, episode lists, and video sources.

## Run locally

```bash
cd backend
npm install
npm start
```

The API listens on `http://localhost:3000` by default.

- `GET /health`
- `GET /api/search?q=One%20Piece`
- `GET /api/info/12-one-piece`
- `GET /api/sources/12-one-piece/5991`

The frontend is already configured to use `http://localhost:3000` unless `CONSUMET_BACKEND_URL` is set to another public backend URL.
