import { PrismaClient } from "@prisma/client";

let prisma: PrismaClient | null = null;

// Database features are optional. Never instantiate Prisma when DATABASE_URL
// is absent, because Prisma validates the datasource when the first query runs.
if (typeof window === "undefined" && process.env.DATABASE_URL) {
  if (process.env.NODE_ENV === "production") {
    prisma = new PrismaClient();
  } else {
    if (!global.prisma) {
      global.prisma = new PrismaClient();
    }
    prisma = global.prisma;
  }
}

export default prisma;
