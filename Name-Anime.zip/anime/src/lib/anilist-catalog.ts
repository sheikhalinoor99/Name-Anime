/**
 * Server-side AniList catalog adapter.
 *
 * This is deliberately separate from the streaming integration. AniList is
 * used for catalog/search metadata because the meta provider's catalog calls
 * can fail when its upstream cache service is unavailable. @consumet/extensions
 * remains responsible for provider/streaming work in src/lib/consumet.ts.
 */

const ENDPOINT = "https://graphql.anilist.co";

const MEDIA_FIELDS = `
  id
  idMal
  title { romaji english native userPreferred }
  status
  coverImage { extraLarge large medium color }
  bannerImage
  popularity
  description
  averageScore
  genres
  episodes
  duration
  format
  season
  seasonYear
`;

const PAGE_QUERY = `
  query (
    $page: Int,
    $perPage: Int,
    $search: String,
    $type: MediaType,
    $format: MediaFormat,
    $status: MediaStatus,
    $season: MediaSeason,
    $sort: [MediaSort],
    $genres: [String]
  ) {
    Page(page: $page, perPage: $perPage) {
      pageInfo { currentPage hasNextPage lastPage total }
      media(
        type: $type,
        search: $search,
        format: $format,
        status: $status,
        season: $season,
        sort: $sort,
        genre_in: $genres
      ) {
        ${MEDIA_FIELDS}
      }
    }
  }
`;

const DETAILS_QUERY = `
  query ($id: Int) {
    Media(id: $id, type: ANIME) {
      ${MEDIA_FIELDS}
      isLicensed
      isAdult
      countryOfOrigin
      synonyms
      startDate { year month day }
      endDate { year month day }
      nextAiringEpisode { airingAt timeUntilAiring episode }
      studios { nodes { name } }
      relations {
        edges {
          relationType
          node {
            id idMal status episodes format averageScore
            title { romaji english native userPreferred }
            coverImage { extraLarge large medium color }
            bannerImage
          }
        }
      }
      recommendations(perPage: 12, sort: RATING_DESC) {
        nodes {
          mediaRecommendation {
            id idMal status episodes format averageScore
            title { romaji english native userPreferred }
            coverImage { extraLarge large medium color }
            bannerImage
          }
        }
      }
    }
  }
`;

const normalizeArray = (value: unknown): string[] | undefined => {
  if (Array.isArray(value)) return value.map(String).filter(Boolean);
  if (typeof value !== "string" || !value.trim()) return undefined;
  try {
    const parsed = JSON.parse(value);
    if (Array.isArray(parsed)) return parsed.map(String).filter(Boolean);
  } catch {}
  return value.split(",").map((item) => item.trim()).filter(Boolean);
};

const normalizeSort = (value: unknown): string[] | undefined => {
  const values = normalizeArray(value);
  return values?.map((item) => item.toUpperCase().replace(/\s+/g, "_"));
};

const mapAnime = (item: any) => ({
  id: String(item.id),
  malId: item.idMal,
  title: item.title || { romaji: "", native: "", userPreferred: "" },
  image: item.coverImage?.extraLarge || item.coverImage?.large || item.coverImage?.medium || "",
  trailer: { id: "", site: "", thumbnail: "" },
  description: item.description || "",
  status: item.status || "",
  cover: item.bannerImage || item.coverImage?.extraLarge || item.coverImage?.large || "",
  rating: item.averageScore || 0,
  releaseDate: item.seasonYear || 0,
  color: item.coverImage?.color || "",
  genres: item.genres || [],
  totalEpisodes: item.episodes || item.nextAiringEpisode?.episode || 0,
  duration: item.duration || 0,
  type: item.format || "",
});

const mapSearch = (payload: any) => {
  const page = payload?.data?.Page;
  const results = Array.isArray(page?.media) ? page.media.map(mapAnime) : [];
  const info = page?.pageInfo || {};
  return {
    currentPage: Number(info.currentPage || 1),
    hasNextPage: Boolean(info.hasNextPage),
    totalPages: Number(info.lastPage || 0),
    totalResults: Number(info.total || results.length),
    results,
  };
};

const request = async (query: string, variables: Record<string, unknown>) => {
  const response = await fetch(ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query, variables }),
  });

  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload?.errors?.length) {
    const message = payload?.errors?.[0]?.message || `AniList returned HTTP ${response.status}`;
    throw new Error(message);
  }
  return payload;
};

export const searchCatalog = async (queries: Record<string, any> = {}) => {
  const genres = normalizeArray(queries.genres);
  const sort = normalizeSort(queries.sort);
  const variables: Record<string, unknown> = {
    page: Number(queries.page || 1),
    perPage: Math.min(Number(queries.perPage || 20), 50),
    type: queries.type || "ANIME",
    search: queries.query || undefined,
    format: queries.format || undefined,
    status: queries.status || undefined,
    season: queries.season || undefined,
    sort,
    genres,
  };

  return mapSearch(await request(PAGE_QUERY, variables));
};

export const getCatalogAnime = async (mode: "trending" | "popular" | "airing" | "recent", page = 1, perPage = 20) => {
  if (mode === "trending") {
    return searchCatalog({ page, perPage, sort: ["TRENDING_DESC"] });
  }
  if (mode === "popular") {
    return searchCatalog({ page, perPage, sort: ["POPULARITY_DESC"] });
  }
  if (mode === "airing") {
    return searchCatalog({ page, perPage, status: "RELEASING", sort: ["POPULARITY_DESC"] });
  }
  return searchCatalog({ page, perPage, sort: ["UPDATED_AT_DESC"] });
};

export const getCatalogInfo = async (id: string) => {
  const payload = await request(DETAILS_QUERY, { id: Number(id) });
  const item = payload?.data?.Media;
  if (!item) throw new Error("Anime not found");

  const relations = (item.relations?.edges || []).filter((edge: any) => edge?.node).map((edge: any) => ({
    id: Number(edge.node.id),
    relationType: edge.relationType,
    malId: edge.node.idMal,
    title: edge.node.title,
    status: edge.node.status,
    episodes: edge.node.episodes,
    image: edge.node.coverImage?.extraLarge || edge.node.coverImage?.large || edge.node.coverImage?.medium || "",
    color: edge.node.coverImage?.color || "",
    type: edge.node.format || "",
    cover: edge.node.bannerImage || edge.node.coverImage?.extraLarge || "",
    rating: edge.node.averageScore || 0,
  }));

  const recommendations = (item.recommendations?.nodes || []).filter((node: any) => node?.mediaRecommendation).map((node: any) => {
    const anime = node.mediaRecommendation;
    return {
      id: Number(anime.id),
      malId: anime.idMal,
      title: anime.title,
      status: anime.status,
      episodes: anime.episodes,
      image: anime.coverImage?.extraLarge || anime.coverImage?.large || anime.coverImage?.medium || "",
      cover: anime.bannerImage || anime.coverImage?.extraLarge || "",
      rating: anime.averageScore || 0,
      type: anime.format || "",
    };
  });

  return {
    ...mapAnime(item),
    malId: item.idMal,
    synonyms: item.synonyms || [],
    isLicensed: Boolean(item.isLicensed),
    isAdult: Boolean(item.isAdult),
    countryOfOrigin: item.countryOfOrigin || "",
    popularity: item.popularity || 0,
    startDate: item.startDate || { year: 0, month: 0, day: 0 },
    endDate: item.endDate || { year: 0, month: 0, day: 0 },
    nextAiringEpisode: item.nextAiringEpisode || { airingTime: 0, timeUntilAiring: 0, episode: 0 },
    currentEpisode: item.nextAiringEpisode?.episode ? item.nextAiringEpisode.episode - 1 : item.episodes || 0,
    season: item.season || "",
    studios: (item.studios?.nodes || []).map((studio: any) => studio.name),
    subOrDub: "",
    recommendations,
    characters: [],
    relations,
    mappings: { mal: item.idMal },
    episodes: [],
  };
};
