/**
 * Anime integration layer.
 *
 * AniList remains the catalog/metadata source. Provider episode and streaming
 * requests are routed through the separate AnimeUnity Express backend.
 * The existing UI contracts are intentionally unchanged.
 */

export const DEFAULT_PROVIDER = "AnimeUnity";
const BACKEND = (process.env.CONSUMET_BACKEND_URL || "http://localhost:3000").replace(/\/$/, "");

const backendFetch = async (path: string, params: Record<string, any> = {}) => {
  const url = new URL(path, BACKEND + "/");
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  }

  const response = await fetch(url.toString());
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(body?.message || body?.error || `AnimeUnity backend HTTP ${response.status}`);
  }
  return body;
};

const titleText = (title: any) =>
  typeof title === "string"
    ? title
    : title?.english || title?.romaji || title?.native || title?.userPreferred || "";

const providerTitles = (title: any, synonyms: any[] = []) => {
  const values = [
    title?.english,
    title?.romaji,
    title?.native,
    title?.userPreferred,
    titleText(title),
    ...synonyms,
  ];
  return [...new Set(values.filter(Boolean).map(String).map((value) => value.trim()).filter(Boolean))];
};

const titleScore = (target: string, candidate: any) => {
  const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const a = normalize(target);
  const b = normalize(titleText(candidate?.title));
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.9;
  const aw = new Set(a.split(" "));
  const bw = new Set(b.split(" "));
  const common = [...aw].filter((word) => bw.has(word)).length;
  return common / Math.max(aw.size, bw.size);
};

const mapProviderEpisodes = (info: any) => {
  const episodes = Array.isArray(info?.episodes) ? info.episodes : [];
  return episodes.map((episode: any) => ({
    id: String(episode.id),
    title: episode.title || `Episode ${episode.number}`,
    description: episode.description || "",
    number: Number(episode.number || 0),
    image: episode.image || info?.image || "",
    airDate: episode.airDate || "",
  }));
};

const resolveAnimeOnAnimeUnity = async (titles: string[]) => {
  let best: { id: string; score: number } | null = null;

  for (const title of titles) {
    try {
      const result = await backendFetch("/api/search", { q: title });
      const items = Array.isArray(result?.results) ? result.results : [];
      for (const item of items) {
        if (!item?.id) continue;
        const score = titleScore(title, item);
        if (!best || score > best.score) best = { id: String(item.id), score };
      }
      if (best && best.score >= 0.95) break;
    } catch (error) {
      console.warn("AnimeUnity search failed:", error);
    }
  }

  if (!best) return null;
  return backendFetch(`/api/info/${best.id}`);
};

export const getRecentAnime = async (limit = 20, page = 1) => {
  const { getCatalogAnime } = await import("@/src/lib/anilist-catalog");
  return getCatalogAnime("recent", page, limit);
};

export const getTrendingAnime = async (limit = 20, page = 1) => {
  const { getCatalogAnime } = await import("@/src/lib/anilist-catalog");
  return getCatalogAnime("trending", page, limit);
};

export const getTopAiring = async (limit = 20, page = 1) => {
  const { getCatalogAnime } = await import("@/src/lib/anilist-catalog");
  return getCatalogAnime("airing", page, limit);
};

export const getMostPopular = async (limit = 20, page = 1) => {
  const { getCatalogAnime } = await import("@/src/lib/anilist-catalog");
  return getCatalogAnime("popular", page, limit);
};

export const searchAdvanced = async (queries: Record<string, any> = {}) => {
  const { searchCatalog } = await import("@/src/lib/anilist-catalog");
  return searchCatalog(queries);
};

export const getAnimeInfo = async (id: string, _provider = DEFAULT_PROVIDER) => {
  const { getCatalogInfo } = await import("@/src/lib/anilist-catalog");
  const info: any = await getCatalogInfo(id);

  try {
    const providerInfo = await resolveAnimeOnAnimeUnity(providerTitles(info?.title, info?.synonyms || []));
    const episodes = mapProviderEpisodes(providerInfo);
    if (episodes.length) {
      info.episodes = episodes;
      info.totalEpisodes = info.totalEpisodes || providerInfo?.totalEpisodes || episodes.length;
    }
  } catch (error) {
    console.warn("AnimeUnity episode lookup failed:", error);
  }

  return info;
};

export const getAnimeEpisodeStreaming = async (episodeId: string, _provider = DEFAULT_PROVIDER) => {
  const raw = await backendFetch(`/api/sources/${episodeId}`);
  const referer = raw?.headers?.Referer || raw?.headers?.referer || "https://www.animeunity.to/";
  const sources = Array.isArray(raw?.sources) ? raw.sources : [];

  // Do not send provider HLS URLs directly to the browser. Some CDNs require
  // Referer/Origin headers on the playlist, keys, and media segments. Route
  // every HLS request through the backend proxy so the existing player keeps
  // the same UI while receiving a browser-playable URL.
  const proxiedSources = sources.map((source: any) => ({
    ...source,
    url: source?.url
      ? `${BACKEND}/api/proxy?url=${encodeURIComponent(source.url)}&referer=${encodeURIComponent(referer)}`
      : source?.url,
  }));

  return {
    headers: { Referer: referer },
    sources: proxiedSources,
    download: raw?.download || "",
  };
};

export const searchAnime = async (query: string, _page = 1, _provider = DEFAULT_PROVIDER) => {
  return backendFetch("/api/search", { q: query });
};

export const getRandomAnime = async () => {
  const { searchCatalog, getCatalogInfo } = await import("@/src/lib/anilist-catalog");
  const page = await searchCatalog({ sort: ["POPULARITY_DESC"], perPage: 50 });
  const item = page.results[Math.floor(Math.random() * page.results.length)];
  if (!item) throw new Error("No anime available");
  return getCatalogInfo(item.id);
};
