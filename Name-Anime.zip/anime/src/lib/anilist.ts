/** Server-side AniList metadata lookup used only for the character detail page. */

const ANILIST_ENDPOINT = "https://graphql.anilist.co";

const CHARACTER_QUERY = `
  query ($id: Int) {
    Character(id: $id) {
      id
      name {
        first
        last
        full
        native
        userPreferred
      }
      image {
        large
      }
      gender
      dateOfBirth {
        year
        month
        day
      }
      age
      bloodType
      description
      favourites
      media(perPage: 12, sort: POPULARITY_DESC) {
        nodes {
          id
          title {
            romaji
            english
            native
            userPreferred
          }
          coverImage {
            large
            color
          }
          format
          status
          episodes
          averageScore
        }
      }
    }
  }
`;

export const getCharacterInfo = async (id: string) => {
  const response = await fetch(ANILIST_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      query: CHARACTER_QUERY,
      variables: { id: Number(id) },
    }),
  });

  if (!response.ok) {
    throw new Error(`AniList returned HTTP ${response.status}`);
  }

  const payload = await response.json();
  if (payload?.errors?.length || !payload?.data?.Character) {
    throw new Error("Character not found");
  }

  const character = payload.data.Character;

  return {
    id: character.id,
    name: character.name,
    image: character.image?.large,
    gender: character.gender,
    dateOfBirth: character.dateOfBirth,
    age: character.age,
    height: undefined,
    relations: (character.media?.nodes || []).map((anime: any) => ({
      id: anime.id,
      malId: undefined,
      title: anime.title,
      status: anime.status,
      episodes: anime.episodes,
      image: anime.coverImage?.large,
      color: anime.coverImage?.color,
      type: anime.format,
      cover: anime.coverImage?.large,
      rating: anime.averageScore,
    })),
  };
};
