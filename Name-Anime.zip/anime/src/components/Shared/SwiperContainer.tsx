import React, { useMemo, useRef } from "react";
import { Swiper } from "swiper/react";
import { Layout } from "../../types/utils";
import useInnerWidth from "../../hooks/useInnerWidth";

interface SwiperContainerProps extends Layout {
  xl: number;
  lg: number;
  md: number;
  sm: number;
  spaceBetween: number;
  className?: string;
  navigationButtons?: boolean;
}

const SwiperContainer: React.FC<SwiperContainerProps> = ({
  children,
  lg,
  md,
  sm,
  spaceBetween,
  xl,
  className = "",
  navigationButtons = false,
}) => {
  const width = useInnerWidth();
  const swiperRef = useRef<any>(null);

  const slidesPerView = useMemo(() => {
    return width >= 1200 ? xl : width >= 1024 ? lg : width >= 768 ? md : sm;
  }, [width, xl, lg, md, sm]);

  const scrollBy = (direction: "prev" | "next") => {
    const swiper = swiperRef.current;
    if (!swiper) return;

    const amount = Math.max(1, Math.floor(Number(swiper.params.slidesPerView) || 1));
    const target = direction === "next"
      ? swiper.activeIndex + amount
      : swiper.activeIndex - amount;

    swiper.slideTo(Math.max(0, target));
  };

  return (
    <div className={navigationButtons ? "relative group" : "relative"}>
      {navigationButtons && (
        <>
          <button
            type="button"
            aria-label="Scroll anime left"
            className="anime-row-nav anime-row-nav-prev"
            onClick={() => scrollBy("prev")}
          >
            &#10094;
          </button>
          <button
            type="button"
            aria-label="Scroll anime right"
            className="anime-row-nav anime-row-nav-next"
            onClick={() => scrollBy("next")}
          >
            &#10095;
          </button>
        </>
      )}
      <Swiper
        onSwiper={(swiper) => {
          swiperRef.current = swiper;
        }}
        className={className}
        spaceBetween={spaceBetween}
        slidesPerView={slidesPerView}
      >
        {children}
      </Swiper>
    </div>
  );
};

export default SwiperContainer;
