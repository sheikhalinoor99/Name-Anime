import type { NextApiHandler } from "next";
import {
  getAnimeEpisodeStreaming,
  getAnimeInfo,
  getMostPopular,
  getRandomAnime,
  getRecentAnime,
  getTopAiring,
  getTrendingAnime,
  searchAdvanced,
  searchAnime,
  DEFAULT_PROVIDER,
} from "@/src/lib/consumet";

const handler: NextApiHandler = async (req, res) => {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const op = String(req.query.op || "");
    const provider = String(req.query.provider || DEFAULT_PROVIDER);
    const page = Number(req.query.page || 1);
    const limit = Number(req.query.limit || 20);

    let data: unknown;

    switch (op) {
      case "recent":
        data = await getRecentAnime(limit, page, provider);
        break;
      case "trending":
        data = await getTrendingAnime(limit, page);
        break;
      case "airing":
        data = await getTopAiring(limit, page);
        break;
      case "popular":
        data = await getMostPopular(limit, page);
        break;
      case "advanced": {
        const raw = String(req.query.query || "{}");
        data = await searchAdvanced(JSON.parse(raw));
        break;
      }
      case "info":
        data = await getAnimeInfo(String(req.query.id || ""), provider);
        break;
      case "watch":
        data = await getAnimeEpisodeStreaming(
          String(req.query.episodeId || ""),
          provider
        );
        break;
      case "search":
        data = await searchAnime(String(req.query.q || ""), page, provider);
        break;
      case "random":
        data = await getRandomAnime();
        break;
      default:
        return res.status(400).json({ error: "Unknown anime operation" });
    }

    // Keep the original frontend response contracts stable. List endpoints
    // always expose a Consumet-style { results: [] } envelope.
    if (["recent", "trending", "airing", "popular"].includes(op)) {
      const normalized = Array.isArray(data)
        ? { currentPage: 1, hasNextPage: false, totalPages: 1, totalResults: data.length, results: data }
        : {
            currentPage: Number((data as any)?.currentPage || 1),
            hasNextPage: Boolean((data as any)?.hasNextPage),
            totalPages: Number((data as any)?.totalPages || 0),
            totalResults: Number((data as any)?.totalResults || (data as any)?.results?.length || 0),
            results: Array.isArray((data as any)?.results) ? (data as any).results : [],
          };
      return res.status(200).json(normalized);
    }

    return res.status(200).json(data);
  } catch (error: any) {
    console.error("Consumet anime route error:", error);
    return res.status(500).json({
      error: error?.message || "Failed to fetch anime data",
    });
  }
};

export default handler;
