import type { NextApiHandler } from "next";
import { getCharacterInfo } from "@/src/lib/anilist";

const handler: NextApiHandler = async (req, res) => {
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const id = String(req.query.id || "");
    if (!id) return res.status(400).json({ error: "Missing character id" });

    return res.status(200).json(await getCharacterInfo(id));
  } catch (error: any) {
    console.error("Character route error:", error);
    return res.status(500).json({ error: error?.message || "Failed to fetch character" });
  }
};

export default handler;
