import { NextApiHandler, NextApiRequest, NextApiResponse } from "next";
import prisma from "../../lib/prisma";
import { CreateCommentBody } from "@/src/types/comment";
import { getServerSession, Session } from "next-auth";
import { authOptions } from "./auth/[...nextauth]";
import { Like } from "@prisma/client";

const databaseAvailable = () => Boolean(prisma && process.env.DATABASE_URL);

const createComment = async (comment: CreateCommentBody, session: Session | null, res: NextApiResponse) => {
  if (!session?.user) return res.status(400).json("User not login");
  if (!databaseAvailable()) return res.status(503).json({ error: "Comments database is not configured" });
  return prisma!.comment.create({ data: comment });
};

const getNewestComment = async () => {
  if (!databaseAvailable()) return [];
  return prisma!.comment.findMany({
    orderBy: { createdAt: "desc" },
    take: 20,
    include: { user: true },
  });
};

const getCommentByEpisodeId = async (animeId: string, session: Session | null) => {
  if (!databaseAvailable()) return [];
  let likes: Like[] = [];
  const comments = await prisma!.comment.findMany({
    where: { animeId },
    include: { user: true, _count: { select: { like: true } } },
  });
  if (session?.user) {
    likes = await prisma!.like.findMany({
      where: { commentId: { in: comments.map((item) => item.id) }, userId: session.user.id },
    });
  }
  return comments.map((item) => ({ ...item, isLiked: likes.some((p) => p.commentId === item.id) }));
};

const deleteComment = async (req: NextApiRequest, res: NextApiResponse, session: Session | null) => {
  if (!session?.user) return res.status(400).json("User not login");
  if (!databaseAvailable()) return res.status(503).json({ error: "Comments database is not configured" });
  const comment = await prisma!.comment.findFirst({ where: { id: req.query.id as string } });
  if (!comment) return res.status(404).json("Comment not found");
  if (comment.userId !== session.user.id) return res.status(404).json("Something went wrong");
  await Promise.all([
    prisma!.comment.delete({ where: { id: req.query.id as string } }),
    prisma!.like.deleteMany({ where: { commentId: comment.id } }),
  ]);
  return res.json("Delete comment success");
};

const handler: NextApiHandler = async (req, res) => {
  try {
    const session = await getServerSession(req, res, authOptions);
    if (req.method === "POST") return res.json(await createComment(req.body as CreateCommentBody, session, res));
    if (req.method === "GET") return res.json(await getNewestComment());
    if (req.method === "PUT") return res.json(await getCommentByEpisodeId(req.body.animeId, session));
    if (req.method === "DELETE") return deleteComment(req, res, session);
    return res.status(405).json("Method not allowed");
  } catch (error) {
    console.error("Comment API error:", error);
    return res.status(500).json("Server not found!");
  }
};

export default handler;
