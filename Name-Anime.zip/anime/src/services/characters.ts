import axios from "axios";
import { Characters } from "../types/characters";

export const getCharactersInfo = async (id: string) => {
  const response = await axios.get<Characters>(`/api/character?id=${encodeURIComponent(id)}`);
  return response.data;
};
