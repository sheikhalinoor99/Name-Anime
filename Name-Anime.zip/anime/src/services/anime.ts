import {
  Anime,
  AnimeEpisodeStreaming,
  AnimeInfo,
  RecentAnime,
} from "@/src/types/anime";
import { AnimeResponse, SearchAdvancedQuery } from "@/src/types/utils";
import axios from "axios";
import { getNewestComment } from "./comment";

export const default_provider = "AnimeUnity";

const api = async <T>(op: string, params: Record<string, any> = {}) => {
  const search = new URLSearchParams({
    op,
    ...Object.fromEntries(
      Object.entries(params).map(([key, value]) => [key, String(value)])
    ),
  });
  const response = await axios.get<T>(`/api/anime?${search.toString()}`);
  return response.data;
};

export const getRecentAnime = async (limit = 20, page = 1) => {
  const data = await api<AnimeResponse<RecentAnime>>("recent", {
    page,
    limit,
    provider: default_provider,
  });
  return Array.isArray(data?.results) ? data.results : Array.isArray(data) ? data : [];
};

export const getTrendingAnime = async (limit = 20, page = 1) => {
  const data = await api<AnimeResponse<Anime>>("trending", { page, limit });
  return Array.isArray(data?.results) ? data.results : Array.isArray(data) ? data : [];
};

export const getTopAiring = async (limit = 20, page = 1) => {
  const data = await api<AnimeResponse<Anime>>("airing", { page, limit });
  return Array.isArray(data?.results) ? data.results : Array.isArray(data) ? data : [];
};

export const getMostPopular = async (limit = 20, page = 1) => {
  const data = await api<AnimeResponse<Anime>>("popular", { page, limit });
  return Array.isArray(data?.results) ? data.results : Array.isArray(data) ? data : [];
};

export const searchAdvanced = async (queries?: SearchAdvancedQuery) =>
  api<AnimeResponse<Anime>>("advanced", {
    query: JSON.stringify(queries || {}),
  });

export const getAnimeInfo = async (id: string, provider = default_provider) =>
  api<AnimeInfo>("info", { id, provider });

export const getAnimeEpisodeStreaming = async (
  episodeId: string,
  provider = default_provider
): Promise<AnimeEpisodeStreaming> => api<AnimeEpisodeStreaming>("watch", { episodeId, provider });

export const searchAnime = async (query: string, page = 1) =>
  api<AnimeResponse<Anime>>("search", {
    q: query,
    page,
    provider: default_provider,
  });

export const getRandomAnime = async () => api<AnimeInfo>("random");

export const getHomePage = async () => {
  const results = await Promise.allSettled([
    getRecentAnime(),
    getTrendingAnime(),
    getMostPopular(),
    searchAdvanced({ sort: '["FAVOURITES_DESC"]', type: "ANIME" }),
    searchAdvanced({ type: "ANIME", status: "FINISHED", sort: '["SCORE_DESC"]' }),
    getNewestComment().catch(() => []),
    searchAdvanced({ season: "FALL", perPage: 5 }),
    searchAdvanced({ season: "WINTER", perPage: 5 }),
    searchAdvanced({ season: "SPRING", perPage: 5 }),
    searchAdvanced({ season: "SUMMER", perPage: 5 }),
  ]);

  return results.map((result, index) => {
    if (result.status === "fulfilled") return result.value;
    console.error(`Home data request ${index} failed:`, result.reason);

    // The existing homepage expects the first three feeds to be arrays
    // because it calls .map() directly on them. Keep the original response
    // envelope for advanced-search widgets and an array for comments.
    if (index <= 2 || index === 5) return [];

    return {
      currentPage: 1,
      hasNextPage: false,
      totalPages: 0,
      totalResults: 0,
      results: [],
    };
  });
};
