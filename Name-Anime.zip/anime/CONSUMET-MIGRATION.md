# Consumet migration

The UI is unchanged. Provider/streaming work is handled by the bundled `backend/` AnimeUnity service.

AniList remains the source for catalog metadata, recommendations, relations, and page layout data. AnimeUnity supplies provider search, episode IDs, and streaming sources.
