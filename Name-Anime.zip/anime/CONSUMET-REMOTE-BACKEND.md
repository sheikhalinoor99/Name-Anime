# AnimeUnity remote backend

This build keeps the existing UI unchanged and routes provider search, episode lookup, and streaming-source requests through the separate Node/Express backend. The selected provider is **AnimeUnity**.

## Local
1. Start the AnimeUnity backend on port 3000.
2. In the Next.js project set `CONSUMET_BACKEND_URL=http://localhost:3000`.
3. Restart the Next.js app.

## Remote
Set `CONSUMET_BACKEND_URL` to the public URL of the deployed AnimeUnity backend.

The frontend contracts remain unchanged: anime metadata comes from AniList, while provider episode/source data comes from the AnimeUnity backend.
